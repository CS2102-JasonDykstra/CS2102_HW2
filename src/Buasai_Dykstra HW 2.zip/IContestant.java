public interface IContestant {

}
