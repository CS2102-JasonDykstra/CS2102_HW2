public interface IWinner {

    public boolean isWinner(IContestant winner);
}
